package Task;

public class Task {

	final String taskID;
	String name;
	String description;
	
	public Task(String taskID, String name, String description) {
		if(taskID == null || taskID.length() > 10) {
			throw new IllegalArgumentException("Task ID must not be null and cannot be longer than 10 characters");
		}
		
		if(name == null || name.length() > 20) {
			throw new IllegalArgumentException("Name must not be null and cannot be longer than 20 characters");
		}
		
		if(description == null || description.length() > 50) {
			throw new IllegalArgumentException("Description must not be null and cannot be longer than 50 characters");
		}
		
		this.taskID = taskID;
		this.name = name;
		this.description = description;
	}
	
	public String getTaskID() {
		return taskID;
	}
	
	public String getName() {
		return name;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setName(String name) {
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("Name must not be null and cannot be longer than 20 characters");
		}
		this.name = name;
	}
	
	public void setDescription(String description) {
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Description must not be null and cannot be longer than 50 characters");
		}
		this.description = description;
	}

}