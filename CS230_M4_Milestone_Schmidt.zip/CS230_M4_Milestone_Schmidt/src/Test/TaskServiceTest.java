package Test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import Task.Task;
import Task.TaskService;

class TaskServiceTest {

	//Test adding tasks
	@Test
	void testAddTask() {
		TaskService taskService = new TaskService();

		Task task = new Task("1234567890", "Task", "Task Description");
		
		taskService.addTask(task);
		
		Task addedTask = taskService.getTaskID("1234567890");
		
		assertTrue(addedTask.getTaskID().equals(task.getTaskID()));
		assertTrue(addedTask.getName().equals("Task"));
		assertTrue(addedTask.getDescription().equals("Task Description"));

	}
	
	//Test deleting tasks
	@Test
	void testDeleteTask( ) {
		TaskService taskService = new TaskService();
		
		Task task = new Task("1234567890", "Task", "Task Description");

		taskService.addTask(task);
		
		Task addedTask = taskService.getTaskID("1234567890");
		
		assertEquals(addedTask.getTaskID(), task.getTaskID());
		
		boolean isDeleted = taskService.deleteTask("1234567890");
				
		assertTrue(isDeleted);
	}

	//Test updating tasks
	@Test
	void testUpdateTask() {
		TaskService taskService = new TaskService();

		Task task = new Task("1234567890", "Task", "Task Description");
		
		taskService.addTask(task);
		
		Task updatedTask = taskService.getTaskID("1234567890");
		
		assertTrue(updatedTask.getTaskID().equals(task.getTaskID()));
		assertTrue(updatedTask.getName().equals("Task"));
		assertTrue(updatedTask.getDescription().equals("Task Description"));

	}
}

