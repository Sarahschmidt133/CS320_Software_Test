package Test;

import static org.junit.Assert.assertTrue;


import org.junit.jupiter.api.Test;

import Task.Task;

class TaskTest {

	//testing task class has unique ID, name, and description
	@Test
	void testTaskConstructor() {
		Task task = new Task("1234567890", "Task", "Task description");
		assertTrue(task.getTaskID().equals("1234567890"));
		assertTrue(task.getName().equals("Task"));
		assertTrue(task.getDescription().equals("Task description"));
	}
	
	//testing set name 
	@Test
	void testSetName() {
		Task task = new Task("1234567890", "Task", "Task description");
		assertTrue(task.getTaskID().equals("1234567890"));

		String newTaskName = "Task";
		task.setName(newTaskName);
		assertTrue(task.getName().equals(newTaskName));
	}
	
	//testing set description
	@Test
	void testSetDescription() {
		Task task = new Task("1234567890", "Task", "Task description");
		assertTrue(task.getTaskID().equals("1234567890"));

		String newTaskDescription = "Task description";
		task.setName(newTaskDescription);
		assertTrue(task.getDescription().equals(newTaskDescription));
	}

}
