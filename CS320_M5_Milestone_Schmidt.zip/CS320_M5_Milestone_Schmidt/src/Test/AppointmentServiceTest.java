package Test;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import Appointment.Appointment;
import Appointment.AppointmentService;

public class AppointmentServiceTest {

    private AppointmentService appointmentService;
    
    //Have an appt ready
    @Before
    public void setUp() {
        appointmentService = new AppointmentService();
    }

    //Test add appointments with unique ID
    @SuppressWarnings("deprecation")
	@Test
    public void testAddAppointment() {
        String appointmentID = "1234567890";
        
		// Create appointment for 15 minutes from now
		Date appointmentDate = new Date();
		// Java Date is apparently deprecated in favor of Calendar. Assignment says to use Date.
		appointmentDate.setMinutes(appointmentDate.getMinutes() + 15);
		
        String description = "Test appointment";
        appointmentService.addAppointment(appointmentID, appointmentDate, description);

        Appointment appointment = appointmentService.findAppointmentByID(appointmentID);
        assertNotNull(appointment);
        assertEquals(appointmentID, appointment.getAppointmentID());
        assertEquals(appointmentDate, appointment.getAppointmentDate());
        assertEquals(description, appointment.getAppointmentDescription());
    }
    
    //Test add duplicate appointments with unique ID
    @SuppressWarnings("deprecation")
	@Test
    public void testAddDuplicateAppointment() {
        String appointmentID = "1234567890";
        
		// Create appointment for 15 minutes from now
		Date appointmentDate = new Date();
		// Java Date is apparently deprecated in favor of Calendar. Assignment says to use Date.
		appointmentDate.setMinutes(appointmentDate.getMinutes() + 15);
		
        String description = "Test appointment";
        appointmentService.addAppointment(appointmentID, appointmentDate, description);

        try {
            appointmentService.addAppointment(appointmentID, appointmentDate, description);
            fail("Expected an IllegalArgumentException to be thrown");
        } catch (IllegalArgumentException e) {
            assertEquals("Appointment ID must be unique.", e.getMessage());
        }
    }

    //Test delete appointments with unique ID
    @SuppressWarnings("deprecation")
	@Test
    public void testDeleteAppointment() {
        String appointmentID = "1234567890";
        
		// Create appointment for 15 minutes from now
		Date appointmentDate = new Date();
		// Java Date is apparently deprecated in favor of Calendar. Assignment says to use Date.
		appointmentDate.setMinutes(appointmentDate.getMinutes() + 15);
		
        String description = "Test appointment";
        appointmentService.addAppointment(appointmentID, appointmentDate, description);

        appointmentService.deleteAppointment(appointmentID);

        Appointment appointment = appointmentService.findAppointmentByID(appointmentID);
        assertNull(appointment);
    }

    //Test delete null appointments with unique ID
    @Test
    public void testDeleteNonExistentAppointment() {
        String appointmentID = "1234567890";

        try {
            appointmentService.deleteAppointment(appointmentID);
            fail("Expected an IllegalArgumentException to be thrown");
        } catch (IllegalArgumentException e) {
            assertEquals("Appointment with ID " + appointmentID + " not found.", e.getMessage());
        }
    }

}

