package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import java.util.Date;
import Appointment.Appointment;


class AppointmentTest {

	//Creating correct appointments
	@SuppressWarnings("deprecation")
	@Test
	public void testConstructorWithValidArguments() {
		String appointmentID = "1234567890";
        
		// Create appointment for 15 minutes from now
		Date appointmentDate = new Date();
		// Java Date is apparently deprecated in favor of Calendar. Assignment says to use Date.
		appointmentDate.setMinutes(appointmentDate.getMinutes() + 15);
        
        String appointmentDescription = "Appointment description";
        
        Appointment appointment = new Appointment(appointmentID, appointmentDate, appointmentDescription);
        
        assertEquals(appointmentID, appointment.getAppointmentID());
        assertEquals(appointmentDate, appointment.getAppointmentDate());
        assertEquals(appointmentDescription, appointment.getAppointmentDescription());
    }
	
	//testing that appointment ID cannot be null
	@SuppressWarnings("deprecation")
	@Test
    public void testConstructorWithNullAppointmentID() {
        String appointmentID = null;
        
        // Create appointment for 15 minutes from now
     	Date appointmentDate = new Date();
     	// Java Date is apparently deprecated in favor of Calendar. Assignment says to use Date.
     	appointmentDate.setMinutes(appointmentDate.getMinutes() + 15);
     		
        String appointmentDescription = "Appointment description";
        
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(appointmentID, appointmentDate, appointmentDescription);
        });
        
        String expectedMessage = "Appointment ID must be non-null and not longer than 10 characters.";
        String actualMessage = exception.getMessage();
        
        assertTrue(actualMessage.contains(expectedMessage));
    }
	
	//testing appointmentID cannot be longer than 10 characters
	 @SuppressWarnings("deprecation")
	 @Test
	    public void testConstructorWithLongAppointmentID() {
	        String appointmentID = "12345678901";
	        
	        // Create appointment for 15 minutes from now
	     	Date appointmentDate = new Date();
	     	// Java Date is apparently deprecated in favor of Calendar. Assignment says to use Date.
	     	appointmentDate.setMinutes(appointmentDate.getMinutes() + 15);
	     	
	        String appointmentDescription = "Appointment description";
	        
	        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
	            new Appointment(appointmentID, appointmentDate, appointmentDescription);
	        });
	        
	        String expectedMessage = "Appointment ID must be non-null and not longer than 10 characters.";
	        String actualMessage = exception.getMessage();
	        
	        assertTrue(actualMessage.contains(expectedMessage));
	    }
}
