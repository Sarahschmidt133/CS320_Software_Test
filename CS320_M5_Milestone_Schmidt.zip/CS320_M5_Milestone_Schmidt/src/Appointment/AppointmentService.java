package Appointment;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import Appointment.Appointment;

public class AppointmentService {

	//create a List of appointments
    private List<Appointment> appointments = new ArrayList<>();
    
    //Adding new appointment w/unique appt ID
    public void addAppointment(String appointmentID, Date appointmentDate, String description) {
        Appointment appointment = new Appointment(appointmentID, appointmentDate, description);
        if (appointmentExists(appointmentID)) {
            throw new IllegalArgumentException("Appointment ID must be unique.");
        }
        appointments.add(appointment);
        
        System.out.println("New Appointment added");
    }
    
    //Delete appointment w/unique appt ID
    public void deleteAppointment(String appointmentID) {
        Appointment appointment = findAppointmentByID(appointmentID);
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment with ID " + appointmentID + " not found.");
        }
        
        System.out.println("Appointment has been deleted.");
        appointments.remove(appointment);
    }
    
    //Check that appointment w/unique appt ID exists
    public boolean appointmentExists(String appointmentID) {
        for (Appointment appointment : appointments) {
            if (appointment.getAppointmentID().equals(appointmentID)) {
                return true;
            }
        }
        
        System.out.println("Appointment exists.");
        return false;
    }
    
    //Check that appointment w/unique appt ID has been found
    public Appointment findAppointmentByID(String appointmentID) {
        for (Appointment appointment : appointments) {
            if (appointment.getAppointmentID().equals(appointmentID)) {
                return appointment;
            }
        }
        
        System.out.println("Appointment found.");
        return null;
    }
    
}
