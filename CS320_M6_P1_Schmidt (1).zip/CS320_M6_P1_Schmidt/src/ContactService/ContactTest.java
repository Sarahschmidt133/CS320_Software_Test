package ContactService;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import ContactService.Contact;

class ContactTest {
	
	//testing contact class has unique ID, first and last name, number and address
	@Test
	void testContact() {
		Contact contact = new Contact("1234567890", "Johnny", "Bravo", "1245694956", "123 Maintstreet South");
		assertTrue(contact.getContactID().equals("1234567890"));
		assertTrue(contact.getFirstName().equals("Johnny"));
		assertTrue(contact.getLastName().equals("Bravo"));
		assertTrue(contact.getPhoneNumber().equals("1245694956"));
		assertTrue(contact.getAddress().equals("123 Maintstreet South"));
	}
	
	//Contact object shall have a required unique contact ID String contact cannot be null
	@Test
	public void testContactIDIsRequired() {
		Contact contact = new Contact("1234567890", "Johnny", "Bravo", "1245694956", "123 Maintstreet South");
		 Assertions.assertThrows(IllegalArgumentException.class, () -> {
			 contact.setContactID(null);
		 });
	}
	
	//Contact ID not update able
	@Test
	public void testContactIDIsNotUpdateable() {
	Contact contact = new Contact("1234567890", "Johnny", "Bravo", "1245694956", "123 Maintstreet South");
	Assertions.assertThrows(IllegalArgumentException.class, () -> {
		contact.setContactID("1234567890");
	 });
	}
	
	//Contact ID is too long
	@Test
	public void testContactIDLengthIsTooLong() {
	Contact contact = new Contact("1234567890", "Johnny", "Bravo", "1245694956", "123 Maintstreet South");
	Assertions.assertThrows(IllegalArgumentException.class, () -> {
		contact.setContactID("1234567890x");
	 });
	}
	
	//First Name Required
	@Test
    public void testFirstNameIsRequired() {
        Contact contact = new Contact("1234567890", "Johnny", "Bravo", "1245694956", "123 Maintstreet South");
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName(null);
        });
    }
	
	//First name is too long
    @Test
    public void testFirstNameLengthIsNotTooLong() {
        Contact contact = new Contact("1234567890", "Johnny", "Bravo", "1245694956", "123 Maintstreet South");
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName("ThisNameIsTooLong");
        });
    }
    
    //First name cannot be null
    @Test
    public void testFirstNameCannotBeNull() {
        Contact contact = new Contact("1234567890", "Johnny", "Bravo", "1245694956", "123 Maintstreet South");
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName(null);
        });
    }
    
	//Last Name Required
	@Test
    public void testLastNameIsRequired() {
        Contact contact = new Contact("1234567890", "Johnny", "Bravo", "1245694956", "123 Maintstreet South");
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName(null);
        });
    }
	
	//First name is too long
    @Test
    public void testLasttNameLengthIsNotTooLong() {
        Contact contact = new Contact("1234567890", "Johnny", "Bravo", "1245694956", "123 Maintstreet South");
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName("ThisLastNameIsTooLong");
        });
    }
    
    //Phone number is 10 digits
    @Test
    public void testPhoneIsExactly10Digits() {
        Contact contact = new Contact("1234567890", "Johnny", "Bravo", "1245694956", "123 Maintstreet South");
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contact.setPhoneNumber("01234567890");
        });
    }
    
    //Address Required
    @Test
    public void testAddressIsRequired() {
        Contact contact = new Contact("1234567890", "Johnny", "Bravo", "1245694956",  "123 Maintstreet South");
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contact.setAddress(null);
        });
    }
    
    //Address isn't too long
    @Test
    public void testAddressLengthIsNotTooLong() {
        Contact contact = new Contact("1234567890", "Johnny", "Bravo", "1245694956",  "123 Maintstreet South");
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contact.setAddress("ThisAddressIsWayTooLongToBeAccepted");
        });
    }
}

