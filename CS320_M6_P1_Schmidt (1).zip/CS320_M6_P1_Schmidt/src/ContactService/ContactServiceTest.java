package ContactService;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import ContactService.Contact;
import ContactService.ContactService;

class ContactServiceTest {

	//Test adding contacts
	@Test
	void testAddContact() {
		ContactService contactService = new ContactService();

		Contact contact = new Contact("1234567890", "Johnny", "Bravo", "1245694956", "123 Maintstreet South");
		
		contactService.addContact(contact);
		
		Contact addedContact = contactService.getContact("1234567890");
		
		assertTrue(addedContact.getContactID().equals(contact.getContactID()));
		assertTrue(addedContact.getFirstName().equals("Johnny"));
		assertTrue(addedContact.getLastName().equals("Bravo"));
		assertTrue(addedContact.getPhoneNumber().equals("1245694956"));
		assertTrue(addedContact.getAddress().equals("123 Maintstreet South"));
	}
	
	//Contact ID is unique
	@Test
	public void testContactIDIsUnique() {
		ContactService contactService = new ContactService();

		Contact contact1 = new Contact("1234567890", "Johnny", "Bravo", "1245694956", "123 Maintstreet South");
		Contact contact2 = new Contact("1234567890", "Rosey", "Lenson", "4993560234", "555 Road Drive");
		
		contactService.addContact(contact1);
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.addContact(contact2);
		 });
	}
	
	//Test deleting contacts
	@Test
	void testDeleteContact( ) {
		ContactService contactService = new ContactService();
		
		Contact contact = new Contact("1234567890", "Johnny", "Bravo", "1245694956", "123 Maintstreet South");

		contactService.addContact(contact);
		
		Contact addedContact = contactService.getContact("1234567890");
		
		assertNotNull(addedContact.getContactID().equals(contact.getContactID()));
		
		contactService.deleteContact(contact.getContactID());
		
		Contact deleteContact = contactService.getContact("1234567890");
		
		assertNull(deleteContact);
		
		
	}

	//Test updating contacts
	@Test
	void testUpdateContact() {
		ContactService contactService = new ContactService();
		
		Contact contact = new Contact("1234567890", "Johnny", "Bravo", "1245694956", "123 Maintstreet South");
		
		contactService.addContact(contact);
		
		contactService.updateContact(contact.getContactID(), "Sully", "Adle", "1234442567", "345 Babalone Ave");
		
		Contact updateContact = contactService.getContact("1234567890");
		
		assertTrue(updateContact.getContactID().equals(contact.getContactID()));
		assertTrue(updateContact.getFirstName().equals("Sully"));
		assertTrue(updateContact.getLastName().equals("Adle"));
		assertTrue(updateContact.getPhoneNumber().equals("1234442567"));
		assertTrue(updateContact.getAddress().equals("345 Babalone Ave"));
	}
}
	
