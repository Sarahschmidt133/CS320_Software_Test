package TaskService;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import TaskService.Task;

class TaskTest {

	//testing task class has unique ID, name, and description
	@Test
	void testTaskConstructor() {
		Task task = new Task("1234567890", "Task", "Task description");
		assertTrue(task.getTaskID().equals("1234567890"));
		assertTrue(task.getName().equals("Task"));
		assertTrue(task.getDescription().equals("Task description"));
	}
	
	//Test object shall have a required unique test ID String contact cannot be null
	@Test
	public void testTaskIDIsRequired() {
		 Assertions.assertThrows(IllegalArgumentException.class, () -> {
			 new Task(null, "Task", "Task description");
		 });
	}
	
	//Test object shall not be  longer than 10 characters
	@Test
	public void testTaskIDIsTooLong() {
		 Assertions.assertThrows(IllegalArgumentException.class, () -> {
			 new Task("123456789055", "Task", "Task description");
		 });
	}
	
	//testing set name 
	@Test
	void testSetName() {
		Task task = new Task("1234567890", "Task", "Task description");
		assertTrue(task.getTaskID().equals("1234567890"));

		String newTaskName = "Task";
		task.setName(newTaskName);
		assertTrue(task.getName().equals(newTaskName));
	}
	
	//Test name cannot be longer than 20 characters
	@Test
	public void testTaskNameIsTooLong() {
		 Assertions.assertThrows(IllegalArgumentException.class, () -> {
			 new Task("123456789055", "Task is too Long, very very long", "Task description");
		 });
	}
	
	//Test name shall not be null
	@Test
	public void testTaskNameCannotBeNull() {
		 Assertions.assertThrows(IllegalArgumentException.class, () -> {
			 new Task("123456789055", null, "Task description");
		 });
	}
	
	//testing set description
	@Test
	void testSetDescription() {
		Task task = new Task("1234567890", "Task", "Task description");
		assertTrue(task.getTaskID().equals("1234567890"));

		String newTaskDescription = "Task description";
		task.setName(newTaskDescription);
		assertTrue(task.getDescription().equals(newTaskDescription));
	}
	
	//Test Description shall not be longer than 50 characters
	@Test
	public void testTaskDescriptionIsTooLong() {
		 Assertions.assertThrows(IllegalArgumentException.class, () -> {
			 new Task("123456789055", "Task", "Task description is too long, very very very long. 50 characters is a lot of string, and not much description.... WHAT TASK, OHHHHHH THIS TASK");
		 });
	}
	
	//Test Description shall not be null
	@Test
	public void testTaskDescriptionCannotNull() {
		 Assertions.assertThrows(IllegalArgumentException.class, () -> {
			 new Task("123456789055", "Task", null);
		 });
	}

}
