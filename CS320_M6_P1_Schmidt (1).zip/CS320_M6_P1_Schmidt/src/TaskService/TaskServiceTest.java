package TaskService;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import TaskService.Task;
import TaskService.TaskService;

class TaskServiceTest {

	//Test adding tasks
	@Test
	void testAddTask() {
		TaskService taskService = new TaskService();

		Task task = new Task("1234567890", "Task", "Task Description");
		
		taskService.addTask(task);
		
		Task addedTask = taskService.getTaskID("1234567890");
		
		assertTrue(addedTask.getTaskID().equals(task.getTaskID()));
		assertTrue(addedTask.getName().equals("Task"));
		assertTrue(addedTask.getDescription().equals("Task Description"));

	}
	
	//Task ID is unique
	@Test
	public void testContactIDIsUnique() {
		TaskService taskService = new TaskService();

		Task task1 = new Task("1234567890", "Task", "Task Description");
		Task task2 = new Task("1234567890", "Task2", "Task Description2");

		taskService.addTask(task1);
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			taskService.addTask(task2);
		 });
	}
	
	//Test deleting tasks
	@Test
	void testDeleteTask( ) {
		TaskService taskService = new TaskService();
		
		Task task = new Task("1234567890", "Task", "Task Description");

		taskService.addTask(task);
		
		Task addedTask = taskService.getTaskID("1234567890");
		
		assertEquals(addedTask.getTaskID(), task.getTaskID());
		
		boolean isDeleted = taskService.deleteTask("1234567890");
				
		assertTrue(isDeleted);
	}

	//Test updating tasks
	@Test
	void testUpdateTask() {
		TaskService taskService = new TaskService();

		Task task = new Task("1234567890", "Task", "Task Description");
		
		taskService.addTask(task);
		
		Task updatedTask = taskService.getTaskID("1234567890");
		
		assertTrue(updatedTask.getTaskID().equals(task.getTaskID()));
		assertTrue(updatedTask.getName().equals("Task"));
		assertTrue(updatedTask.getDescription().equals("Task Description"));

	}
}

