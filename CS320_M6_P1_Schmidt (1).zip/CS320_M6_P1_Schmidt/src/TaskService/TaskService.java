package TaskService;

import java.util.HashMap;
import java.util.Map;

import TaskService.Task;

public class TaskService {
	//Task service add tasks w/unique contact ID.
	 private Map<String, Task> taskMap;
	  
	 public TaskService() {
	   taskMap = new HashMap<String, Task>();
	  }

	public void addTask(Task task) {
	   if (taskMap.containsKey(task.getTaskID())) {
	     throw new IllegalArgumentException("Contact with id " + task.getTaskID() + " already exists.");
	    }
	   taskMap.put(task.getTaskID(), task);
	  }
	  
	 public Task getTaskID(String ID) {
		 return taskMap.get(ID);
	 }
	 
	 //task service fields should be deleting tasks w/ unique contact ID
	 public boolean deleteTask(String ID) {
		 Task removedTask = taskMap.remove(ID);
		 if (removedTask == null) {
			 return false;
		 }
		 
		 System.out.println("Task Deleted");
		 
		 return true;
	 }

	//update task fields
	 public boolean updateTask(String ID, String name, String description) {
		    Task task = taskMap.get(ID);
		    if (taskMap == null) {
		      throw new IllegalArgumentException("Contact with ID " + ID + " does not exist.");
		    }
		    
		    System.out.println("Task Updated");
		    
		    task.setName(name);
		    task.setDescription(description);
		    return true;
	 }
}
