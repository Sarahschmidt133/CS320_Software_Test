package AppointmentService;

import java.util.Date;


public class Appointment {
	private String appointmentID;
	private Date appointmentDate;
	private String appointmentDescription;

	//Create Appointments that have unique appt ID, Date and description
	public Appointment(String appointmentID, Date appointmentDate, String appointmentDescription) {
		Date currentDate = new Date();
		
		//Requirements for unique Appt ID cannot be null and cannot be longer than 10 characters
		if(appointmentID == null|| appointmentID.length() > 10) {
			throw new IllegalArgumentException("Appointment ID must be non-null and not longer than 10 characters.");
		}
		this.appointmentID = appointmentID;
		
		if(appointmentDate == null) {
			throw new IllegalArgumentException("Appointment date must be non-null.");
		}
		
		//Requirements for the date to not be null and cannot be in the past
		if(appointmentDate.before(currentDate)) {
			long msDiff = currentDate.getTime() - appointmentDate.getTime();
			System.out.println("Input date: " + appointmentDate.getTime() + "  Current date: " + currentDate.getTime() + "  Diff: " + msDiff);
			throw new IllegalArgumentException("Appointment cannot be in the a past.");
		}

		this.appointmentDate = appointmentDate;
		
		//Requirements for appt description to not be null and no longer than 50 characters
		if(appointmentDescription == null|| appointmentDescription.length() > 50) {
			throw new IllegalArgumentException("Description of the appointment must be non-null and not longer than 50 characters.");
		}
		this.appointmentDescription = appointmentDescription;
	}
	
		public String getAppointmentID() {
			return appointmentID;
		}

		public Date getAppointmentDate() {
			return appointmentDate;
		}
		
		public String getAppointmentDescription() {
			return appointmentDescription;
		}
		
	}
	
