package AppointmentService;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


class AppointmentTest {

	@SuppressWarnings("deprecation")
	@Test
	void testAppointment() {
		String appointmentID = "1234567890";
        
		// Create appointment for 15 minutes from now
		Date appointmentDate = new Date();
		// Java Date is apparently deprecated in favor of Calendar. Assignment says to use Date.
		appointmentDate.setMinutes(appointmentDate.getMinutes() + 15);
        
        String appointmentDescription = "Appointment description";
        
        Appointment appointment = new Appointment(appointmentID, appointmentDate, appointmentDescription);
        
        assertEquals(appointmentID, appointment.getAppointmentID());
        assertEquals(appointmentDate, appointment.getAppointmentDate());
        assertEquals(appointmentDescription, appointment.getAppointmentDescription());
	}

	@SuppressWarnings("deprecation")
	@Test
	void testGetAppointmentID() {
		String appointmentID = "1234567890";
		Date appointmentDate = new Date();
		appointmentDate.setMinutes(appointmentDate.getMinutes() + 15);
        String appointmentDescription = "Appointment description";
        
        Appointment appointment = new Appointment(appointmentID, appointmentDate, appointmentDescription);
        
        assertEquals(appointment.getAppointmentID(), appointmentID);
	}

	@SuppressWarnings("deprecation")
	@Test
	void testGetAppointmentDate() {
		String appointmentID = "1234567890";
		Date appointmentDate = new Date();
		appointmentDate.setMinutes(appointmentDate.getMinutes() + 15);
        String appointmentDescription = "Appointment description";
        
        Appointment appointment = new Appointment(appointmentID, appointmentDate, appointmentDescription);
        
        assertEquals(appointment.getAppointmentDate(), appointmentDate);
	}

	@SuppressWarnings("deprecation")
	@Test
	void testGetAppointmentDescription() {
		String appointmentID = "1234567890";
		Date appointmentDate = new Date();
		appointmentDate.setMinutes(appointmentDate.getMinutes() + 15);
        String appointmentDescription = "Appointment description";
        
        Appointment appointment = new Appointment(appointmentID, appointmentDate, appointmentDescription);
        
        assertEquals(appointment.getAppointmentDescription(), appointmentDescription);
	}
	
	//testing that appointment ID cannot be null
		@SuppressWarnings("deprecation")
		@Test
	    public void testConstructorWithNullAppointmentID() {
	        String appointmentID = null;
	        
	        // Create appointment for 15 minutes from now
	     	Date appointmentDate = new Date();
	     	// Java Date is apparently deprecated in favor of Calendar. Assignment says to use Date.
	     	appointmentDate.setMinutes(appointmentDate.getMinutes() + 15);
	     		
	        String appointmentDescription = "Appointment description";
	        
	        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
	            new Appointment(appointmentID, appointmentDate, appointmentDescription);
	        });
	        
	        String expectedMessage = "Appointment ID must be non-null and not longer than 10 characters.";
	        String actualMessage = exception.getMessage();
	        
	        assertTrue(actualMessage.contains(expectedMessage));
	    }
		
		//testing appointmentID cannot be longer than 10 characters
		 @SuppressWarnings("deprecation")
		 @Test
		    public void testConstructorWithLongAppointmentID() {
		        String appointmentID = "12345678901";
		        
		        // Create appointment for 15 minutes from now
		     	Date appointmentDate = new Date();
		     	// Java Date is apparently deprecated in favor of Calendar. Assignment says to use Date.
		     	appointmentDate.setMinutes(appointmentDate.getMinutes() + 15);
		     	
		        String appointmentDescription = "Appointment description";
		        
		        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
		            new Appointment(appointmentID, appointmentDate, appointmentDescription);
		        });
		        
		        String expectedMessage = "Appointment ID must be non-null and not longer than 10 characters.";
		        String actualMessage = exception.getMessage();
		        
		        assertTrue(actualMessage.contains(expectedMessage));
		    }
		 
			//Appointment Date shall not be null
			@Test
			public void testAppointmentDateCannotNull() {
				 Assertions.assertThrows(IllegalArgumentException.class, () -> {
					 new Appointment("1234567890", null, "Appointment Description");
				 });
			}
			
			//testing appointment Date cannot be in the past
			@SuppressWarnings("deprecation")
			@Test
			public void testAppointmentDateInPast() {
				// Create appointment for past
		     	Date appointmentDate = new Date();
		     	// Java Date is apparently deprecated in favor of Calendar. Assignment says to use Date.
		     	appointmentDate.setMinutes(appointmentDate.getMinutes() - 1);
		     	
		     	Assertions.assertThrows(IllegalArgumentException.class, () -> {
					 new Appointment("1234567890", appointmentDate, "Appointment Description");
				 });
			}

			//Appointment Description shall not be longer than 50 characters
			@Test
			public void testAppointmentDescriptionIsTooLong() {
		     	@SuppressWarnings("unused")
				Date appointmentDate = new Date();
				 Assertions.assertThrows(IllegalArgumentException.class, () -> {
					 new Appointment("1234567890", appointmentDate, "Task description is too long, very very very long. 50 characters is a lot of string, and not much description.... WHAT TASK, OHHHHHH THIS TASK");
				 });
			}
			
			//Appointment Description shall not be null
			@Test
			public void testAppointmentDescriptionCannotNull() {
		     	Date appointmentDate = new Date();
				 Assertions.assertThrows(IllegalArgumentException.class, () -> {
					 new Appointment("1234567890", appointmentDate, null);
				 });
			}

}
