package AppointmentService;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {
	
	private AppointmentService appointmentService;
	
	@BeforeEach
    public void setUp() {
        appointmentService = new AppointmentService();
    }

	@SuppressWarnings("deprecation")
	@Test
	void testAddAppointment() {
		String appointmentID = "1234567890";
        
		// Create appointment for 15 minutes from now
		Date appointmentDate = new Date();
		// Java Date is apparently deprecated in favor of Calendar. Assignment says to use Date.
		appointmentDate.setMinutes(appointmentDate.getMinutes() + 15);
		
        String description = "Test appointment";
        appointmentService.addAppointment(appointmentID, appointmentDate, description);

        Appointment appointment = appointmentService.findAppointmentByID(appointmentID);
        assertNotNull(appointment);
        assertEquals(appointmentID, appointment.getAppointmentID());
        assertEquals(appointmentDate, appointment.getAppointmentDate());
        assertEquals(description, appointment.getAppointmentDescription());
	}

	@SuppressWarnings("deprecation")
	@Test
	void testDeleteAppointment() {
		String appointmentID = "1234567890";
        
		// Create appointment for 15 minutes from now
		Date appointmentDate = new Date();
		// Java Date is apparently deprecated in favor of Calendar. Assignment says to use Date.
		appointmentDate.setMinutes(appointmentDate.getMinutes() + 15);
		
        String description = "Test appointment";
        appointmentService.addAppointment(appointmentID, appointmentDate, description);

        appointmentService.deleteAppointment(appointmentID);

        Appointment appointment = appointmentService.findAppointmentByID(appointmentID);
        assertNull(appointment);
	}

	@SuppressWarnings("deprecation")
	@Test
	void testAppointmentExists() {
		String appointmentID = "12345";
		
		assertEquals(appointmentService.appointmentExists(appointmentID), false);
		
		Date appointmentDate = new Date();
		appointmentDate.setMinutes(appointmentDate.getMinutes() + 15);
        String description = "Test appointment";
        appointmentService.addAppointment(appointmentID, appointmentDate, description);
		
		assertEquals(appointmentService.appointmentExists(appointmentID), true);
	}

	@SuppressWarnings("deprecation")
	@Test
	void testFindAppointmentByID() {
		String appointmentID = "12345";
		
		assertEquals(appointmentService.findAppointmentByID(appointmentID), null);
		
		Date appointmentDate = new Date();
		appointmentDate.setMinutes(appointmentDate.getMinutes() + 15);
        String description = "Test appointment";
        appointmentService.addAppointment(appointmentID, appointmentDate, description);
        
        Appointment storedAppointment = appointmentService.findAppointmentByID(appointmentID);
        
		assertNotNull(storedAppointment);
        assertEquals(appointmentID, storedAppointment.getAppointmentID());
        assertEquals(appointmentDate, storedAppointment.getAppointmentDate());
        assertEquals(description, storedAppointment.getAppointmentDescription());
	}
	
	@SuppressWarnings("deprecation")
	@Test
    public void testAddDuplicateAppointment() {
        String appointmentID = "1234567890";
        
		// Create appointment for 15 minutes from now
		Date appointmentDate = new Date();
		// Java Date is apparently deprecated in favor of Calendar. Assignment says to use Date.
		appointmentDate.setMinutes(appointmentDate.getMinutes() + 15);
		
        String description = "Test appointment";
        appointmentService.addAppointment(appointmentID, appointmentDate, description);

        try {
            appointmentService.addAppointment(appointmentID, appointmentDate, description);
            fail("Expected an IllegalArgumentException to be thrown");
        } catch (IllegalArgumentException e) {
            assertEquals("Appointment ID must be unique.", e.getMessage());
        }
    }
	
	@Test
    public void testDeleteNonExistentAppointment() {
        String appointmentID = "1234567890";

        try {
            appointmentService.deleteAppointment(appointmentID);
            fail("Expected an IllegalArgumentException to be thrown");
        } catch (IllegalArgumentException e) {
            assertEquals("Appointment with ID " + appointmentID + " not found.", e.getMessage());
        }
    }

}
