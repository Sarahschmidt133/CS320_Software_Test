package Contact;
import java.util.*;

public class ContactService {

	//contact service adding contacts w/unique contact ID.
	 private Map<String, Contact> contacts;
	  
	 public ContactService() {
	   contacts = new HashMap<String, Contact>();
	  }

	 public void addContact(Contact contact) {
	   if (contacts.containsKey(contact.contactID)) {
	     throw new IllegalArgumentException("Contact with id " + contact.contactID + " already exists.");
	    }
	   contacts.put(contact.contactID, contact);
	  }
	  
	 public Contact getContact(String id) {
		 return contacts.get(id);
	 }
	 
	 //contact service deleting contacts w/ unique contact ID
	 public void deleteContact(String id) {
		 contacts.remove(id);
	 }

	//update contacts
	 public void updateContact(String id, String firstName, String lastName, String phoneNumber, String address) {
		    Contact contact = contacts.get(id);
		    if (contact == null) {
		      throw new IllegalArgumentException("Contact with id " + id + " does not exist.");
		    }
		    
		    contact.setFirstName(firstName);
		    contact.setLastName(lastName);
		    contact.setPhoneNumber(phoneNumber);
		    contact.setAddress(address);
	 }
}
