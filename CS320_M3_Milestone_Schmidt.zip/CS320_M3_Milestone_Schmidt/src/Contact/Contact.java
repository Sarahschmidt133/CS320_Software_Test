package Contact;

public class Contact {
	//contact properties
	String contactID;
	String firstName;
	String lastName;
	String phoneNumber;
	String address;
	
	//set contact properties
	public Contact(String contactID, String firstName, String lastName, String phoneNumber, String address) {
		this.setContactID(contactID);
		this.setFirstName(firstName);
		this.setLastName(lastName);
		this.setPhoneNumber(phoneNumber);
		this.setAddress(address);
	}
	
	//get contactID
	public String getContactID() {
		return contactID;
	}

	//create arguments for contact ID
	public void setContactID(String contactID) {
		if(contactID == null || contactID.length() > 10) {
			throw new IllegalArgumentException("Contact ID must not be null and must not be longer than 10 characters.");
		}
		this.contactID = contactID;
	}

	//get first name
	public String getFirstName() {
		return firstName;
	}
	
	//create arguments for first name
	public void setFirstName(String firstName) {
		if (firstName == null) {
			throw new IllegalArgumentException("First name cannot be null");
		}
		if (firstName.length() > 10) {
			throw new IllegalArgumentException("First name cannot be longer than 10 characters");
		}
		
		this.firstName = firstName;
	}
	
	//get last name
	public String getLastName() {
		return lastName;
	}
	
	//create arguments for last name
	public void setLastName(String lastName) {
		if (firstName == null) {
			throw new IllegalArgumentException("First name cannot be null");
		}
		if (firstName.length() > 10) {
			throw new IllegalArgumentException("First name cannot be longer than 10 characters");
		}
		
		this.lastName = lastName;
	}
	
	//get phone number
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	//create arguments for phone number
	public void setPhoneNumber(String phoneNumber) {
		if (phoneNumber == null) {
			throw new IllegalArgumentException("Phone number Cannot be null");
		}
		
		if (phoneNumber.length() != 10) {
			throw new IllegalArgumentException("Phone number has to be exactly 10 digits");
		}
		
		this.phoneNumber = phoneNumber;
	}
	
	//get address
	public String getAddress() {
		return address;
	}
	
	//create arguments for argument
	public void setAddress(String address) {
		if (address == null) {
	      throw new IllegalArgumentException("address cannot be null");
	    }
	    if (address.length() > 30) {
	      throw new IllegalArgumentException("address cannot be longer than 30 characters");
	    }
	    
	    this.address = address;
	}
}