package Test;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;

import Contact.Contact;

class ContactTest {
	
	//testing contact class has unique ID, first and last name, number and address
	@Test
	void testContact() {
		Contact contact = new Contact("1234567890", "Johnny", "Bravo", "1245694956", "123 Maintstreet South");
		assertTrue(contact.getContactID().equals("1234567890"));
		assertTrue(contact.getFirstName().equals("Johnny"));
		assertTrue(contact.getLastName().equals("Bravo"));
		assertTrue(contact.getPhoneNumber().equals("1245694956"));
		assertTrue(contact.getAddress().equals("123 Maintstreet South"));
	}
}

